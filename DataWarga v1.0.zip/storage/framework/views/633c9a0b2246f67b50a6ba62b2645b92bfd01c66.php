

<?php $__env->startSection('title','Administrator - Aplikasi Data Warga'); ?>
<?php $__env->startSection('AdminIndex'); ?>
<section>
	<div class="container-fluid mt-2 bg-light">
		<?php if($errors->count() > 0): ?>
		<div class="alert alert-warning">
			<h5 class="alert-heading">Peringatan!</h5>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($err); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col-lg-3 mt-1">
				<div class="bg-info text-light p-2 rounded-lg shadow shadow-sm text-center border">
					<h2 class="display-4 mb-0 font-weight-bolder"><?php echo e($RW->count()); ?> RW</h2>
					<a href="<?php echo e(url('export/rw')); ?>" class="btn btn-light btn-block btn-sm">Export Excel</a>
				</div>
			</div>
			<div class="col-lg-3 mt-1">
				<div class="bg-primary text-light p-2 rounded-lg shadow shadow-sm text-center">
					<h2 class="display-4 mb-0 font-weight-bolder"><?php echo e($RT->count()); ?> RT</h2>
					<a href="<?php echo e(url('export/rt')); ?>" class="btn btn-light btn-block btn-sm">Export Excel</a>
				</div>
			</div>
			<div class="col-lg-3 mt-1">
				<div class="bg-warning text-light p-2 rounded-lg shadow shadow-sm text-center">
					<h2 class="display-4 mb-0 font-weight-bolder"><?php echo e($KK->count()); ?> KK</h2>
					<a href="<?php echo e(url('export/kk')); ?>" class="btn btn-light btn-block btn-sm">Export Excel</a>
				</div>
			</div>
			<div class="col-lg-3 mt-1">
				<div class="bg-dark text-light p-2 rounded-lg shadow shadow-sm text-center">
					<h2 class="display-4 mb-0 font-weight-bolder"><?php echo e($K->count()); ?> W</h2>
					<a href="<?php echo e(url('export/k')); ?>" class="btn btn-light btn-block btn-sm">Export Excel</a>
				</div>
			</div>
			<div class="col-lg-12 mt-2">
				<div class="bg-light p-2 shadow shadow-sm">
					<h2>Data RW</h2>
					<?php if($RW->count() > 0): ?>
					<div class="table-responsive">
						<table class="table table-bordered table-sm" id="RWTable">
							<thead>
								<tr>
									<th>
										Nama Lengkap
									</th>
									<th>
										No RW
									</th>
									<th>
										No NIK
									</th>
									<th>
										No KK
									</th>
									<th>
										TTL
									</th>
									<th>
										Jenis Kelamin
									</th>
									<th>
										Gol-darah
									</th>
									<th>
										Alamat
									</th>
									<th>
										Agama
									</th>
									<th>
										Status Perkawinan
									</th>
									<th>
										Aksi Data
									</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $RW; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datarw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<?php echo e($datarw->nama_lengkap); ?>

									</td>
									<td>
										<?php echo e($datarw->no_rw); ?>

									</td>
									<td>
										<?php echo e($datarw->no_nik); ?>

									</td>
									<td>
										<?php echo e($datarw->no_kk); ?>

									</td>
									<td>
										<?php echo e($datarw->ttl); ?>

									</td>
									<td>
										<?php echo e($datarw->jenis_kelamin); ?>

									</td>
									<td>
										<?php echo e($datarw->golongan_darah); ?>

									</td>
									<td>
										<?php echo e($datarw->alamat); ?>

									</td>
									<td>
										<?php echo e($datarw->agama); ?>

									</td>
									<td>
										<?php echo e($datarw->status_perkawinan); ?>

									</td>
									<td>
										<div class="btn-group">
											<button class="btn btn-sm btn-primary" data-id="<?php echo e($datarw->id); ?>" onclick="editDataRw(this)">Edit</button>

											<button class="btn btn-sm btn-danger" onclick="hapusData(this)" data-url="<?php echo e(url('hapus/rw/'.$datarw->id)); ?>">Hapus</button>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<?php else: ?>
					<div class="alert alert-info">
						<h4 class="alert-heading">Informasi</h4>
						<hr>
						<p>Data RW belum di tambahkan, silahkan klik tombol <strong>Tambah RW</strong> untuk menambahkan!</p>
					</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-lg-12 mt-2">
				<div class="bg-light p-2 shadow shadow-sm">
					<h2>Data RT</h2>
					<?php if($RT->count() > 0): ?>
					<div class="table-responsive">
						<table class="table table-bordered table-sm" id="RTTable">
							<thead>
								<tr>
									<th>
										Nama Lengkap
									</th>
									<th>
										No RT
									</th>
									<th>
										No RW
									</th>
									<th>
										No NIK
									</th>
									<th>
										No KK
									</th>
									<th>
										TTL
									</th>
									<th>
										Jenis Kelamin
									</th>
									<th>
										Gol-darah
									</th>
									<th>
										Alamat
									</th>
									<th>
										Agama
									</th>
									<th>
										Status Perkawinan
									</th>
									<th>
										Aksi Data
									</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $RT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<?php echo e($datart->nama_lengkap); ?>

									</td>
									<td>
										<?php echo e($datart->no_rt); ?>

									</td>
									<td>
										<?php echo e(App\RW::where('id',$datart->id)->first()->no_rw); ?>

									</td>
									<td>
										<?php echo e($datart->no_nik); ?>

									</td>
									<td>
										<?php echo e($datart->no_kk); ?>

									</td>
									<td>
										<?php echo e($datart->ttl); ?>

									</td>
									<td>
										<?php echo e($datart->jenis_kelamin); ?>

									</td>
									<td>
										<?php echo e($datart->golongan_darah); ?>

									</td>
									<td>
										<?php echo e($datart->alamat); ?>

									</td>
									<td>
										<?php echo e($datart->agama); ?>

									</td>
									<td>
										<?php echo e($datart->status_perkawinan); ?>

									</td>
									<td>
										<div class="btn-group">
											<button class="btn btn-sm btn-primary" data-id="<?php echo e($datart->id); ?>" onclick="editDataRt(this)">Edit</button>

											<button class="btn btn-sm btn-danger" onclick="hapusData(this)" data-url="<?php echo e(url('hapus/rt/'.$datart->id)); ?>">Hapus</button>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<?php else: ?>
					<div class="alert alert-info">
						<h4 class="alert-heading">Informasi</h4>
						<hr>
						<p>Data RT belum di tambahkan, Silahkan klik tombol <strong>Tambah RT</strong> untuk menambahkan!</p>
					</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-lg-12 mt-2">
				<div class="bg-light p-2 shadow shadow-sm">
					<h2>Data Kepala Keluarga</h2>
					<?php if($KK->count() > 0): ?>
					<div class="table-responsive">
						<table class="table table-bordered table-sm" id="KKTable">
							<thead>
								<tr>
									<th>
										Nama Lengkap
									</th>
									<th>
										No NIK
									</th>
									<th>
										No KK
									</th>
									<th>
										No RT
									</th>
									<th>
										No RW
									</th>
									<th>
										TTL
									</th>
									<th>
										Jenis Kelamin
									</th>
									<th>
										Gol-darah
									</th>
									<th>
										Alamat
									</th>
									<th>
										Agama
									</th>
									<th>
										Status Perkawinan
									</th>
									<th>
										Pekerjaan
									</th>
									<th>
										Kewarganegaraan
									</th>
									<th>
										Aksi Data
									</th>
								</tr>
							</thead>

							<tbody>
								<?php $__currentLoopData = $KK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kkeluarga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<?php echo e($kkeluarga->nama_lengkap); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->no_nik); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->no_kk); ?>

									</td>
									<td>
										<?php echo e(App\RT::where('id',$kkeluarga->rt_id)->first()->no_rt); ?>

									</td>
									<td>
										<?php echo e(App\RW::where('id',$kkeluarga->rw_id)->first()->no_rw); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->ttl); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->jenis_kelamin); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->golongan_darah); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->alamat); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->agama); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->status_perkawinan); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->pekerjaan); ?>

									</td>
									<td>
										<?php echo e($kkeluarga->kewarganegaraan); ?>

									</td>
									<td>
										<div class="btn-group w-100">
											<button class="btn btn-sm btn-primary" data-id="<?php echo e($kkeluarga->id); ?>" onclick="editDataKk(this)">Edit</button>

											<button class="btn btn-sm btn-danger" onclick="hapusData(this)" data-url="<?php echo e(url('hapus/kk/'.$kkeluarga->id)); ?>">Hapus</button>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<?php else: ?>
					<div class="alert alert-info">
						<h4 class="alert-heading">Informasi</h4>
						<hr>
						<p>Data Kepala Keluarga belum di tambahkan, Silahkan klik tombol <strong>Tambah Kepala Keluarga</strong> untuk menambahkan!</p>
					</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-lg-12 mt-2">
				<div class="bg-light p-2 shadow shadow-sm">
					<h2>Data Warga</h2>
					<?php if($K->count() > 0): ?>
					<div class="table-responsive">
						<table class="table table-bordered table-sm" id="KTable">
							<thead>
								<tr>
									<th>
										Nama Lengkap
									</th>
									<th>
										No NIK
									</th>
									<th>
										Kepala Keluarga
									</th>
									<th>
										TTL
									</th>
									<th>
										Jenis Kelamin
									</th>
									<th>
										Gol-darah
									</th>
									<th>
										Agama
									</th>
									<th>
										Status Perkawinan
									</th>
									<th>
										Pekerjaan
									</th>
									<th>
										Kewarganegaraan
									</th>
									<th>
										Aksi Data
									</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $K; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataWarga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td>
										<?php echo e($dataWarga->nama_lengkap); ?>

									</td>
									<td>
										<?php echo e($dataWarga->no_nik); ?>

									</td>
									<td>
										<?php echo e(App\KepalaKeluarga::where('id',$dataWarga->kepala_keluarga_id)->first()->nama_lengkap); ?>

									</td>
									<td>
										<?php echo e($dataWarga->ttl); ?>

									</td>
									<td>
										<?php echo e($dataWarga->jenis_kelamin); ?>

									</td>
									<td>
										<?php echo e($dataWarga->golongan_darah); ?>

									</td>
									<td>
										<?php echo e($dataWarga->agama); ?>

									</td>
									<td>
										<?php echo e($dataWarga->status_perkawinan); ?>

									</td>
									<td>
										<?php echo e($dataWarga->pekerjaan); ?>

									</td>
									<td>
										<?php echo e($dataWarga->kewarganegaraan); ?>

									</td>
									<td>
										<div class="btn-group w-100">
											<button class="btn btn-sm btn-primary" onclick="editDataKeluarga(this)" data-id="<?php echo e($dataWarga->id); ?>">Edit</button>

											<button class="btn btn-sm btn-danger" onclick="hapusData(this)" data-url="<?php echo e(url('hapus/k/'.$dataWarga->id)); ?>">Hapus</button>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
					<?php else: ?>
					<div class="alert alert-info">
						<h4 class="alert-heading">Informasi</h4>
						<hr>
						<p>Data Warga belum di tambahkan, Silahkan klik tombol <strong>Tambah Warga</strong> untuk menambahkan!</p>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AdmiN\Documents\Tutorial\data-warga\resources\views/layout/admin.blade.php ENDPATH**/ ?>